module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://wx.gzmibo.com/"'
}
