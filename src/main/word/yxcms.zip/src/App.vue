<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="scss" rel="stylesheet/scss">
#app {
  font-family: 'yahei', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  font-size: 14px;
  background: #F5F7FA;
  min-height: 100vh;
}
 *{
  margin: 0;
  padding: 0;
  list-style: none;
}
a{
  text-decoration: none;
}
.tl{
  text-align: left;
}
.tc{
  text-align: center;
}
.tr{
  text-align: right;
}
.fr{
  float: right;
}
.fl{
  float: left;
}
.pd20{
  padding: 20px;
}
.input{
  display: block;
  width: calc(100% - 42px);
  padding: 12px 20px;
  background: #FFFFFF;
  border: 1px solid #E8E8E8;
  box-shadow: 0 0px 1px 0 rgba(153,153,153,0.30);
  border-radius: 4px;
  margin-bottom: 20px;
}
.actionBar{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  }
  .actionBar > div:first-child{
    color: #8E9AA8;
  }

  .table{
    width: 100%;
    box-shadow: 0 1px 2px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    border-collapse: collapse;
  }
  .table td{
     padding: 10px 0;
  }
  .table > thead > tr{
    height: 40px;
    background: #fff;
    border-bottom: 1px solid #E4E9EF;
    color: #999;
  }
  .table > tbody > tr{
    background: #F3F4F9;
    color: #333;
  }
  .table > td{
     padding: 10px 0;
  }
  .table > tbody > tr:nth-child(2n - 1){
    background: #fff;
  }
  td{
    border: none;
  }
  td > img{
    width: 225px;
    height: 70px;
    border-radius: 4px;
    margin: 10px 0;
  }
  .intable{
    width: 100%;
  }
  .menuRow{
    overflow: hidden;
    border-bottom: 1px solid #E4E9EF;
  }
  .menuRow > li{
    float: left;
  }
  .menuRow > li > a{
    display: block;
    color: #8E9AA8;
    width: 140px;
    padding: 10px 0 13px 0;
    border-radius: 4px 4px 0 0;
  }
  .menuRow > li.active > a{
    background: #EA5B5A;
    color: #fff;
  }

  .modal{
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background: rgba(0, 0, 0, .4);
  }
  .modal > div{
    box-sizing: border-box;
    width: 570px;
    background: #FFFFFF;
    border-radius: 4px;
    margin: 200px auto 0;
  }
  .modal > div > .modal_header{
    padding: 12px 20px 11px;
    border-bottom: 1px solid #e8e8e8;
    font-size: 16px;
    color: #333;
    text-align: left;
  }
  .modal > div > .modal_header > div{
    float: right;
    cursor: pointer;
  }
  .form{
    padding: 20px 80px;
  }
  .form-group{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 20px;
  }
  .form-group > label:first-child{
    width: 80px;
    font-size: 16px;
  }
  .form-group > input{
    display: block;
    padding: 12px 20px;
    background: #FFFFFF;
    border: 1px solid #E8E8E8;
    box-shadow: 0 0px 1px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    width: calc(100% - 150px);
    font-size: 14px;
  }
  .form-group > input::-webkit-input-placeholder{
    color: #A5AFBA;
  }
  .btn{
    width: 132px;
    height: 40px;
    background: #037CFC;
    box-shadow: 0 1px 2px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    border: none;
    color: #fff;
    font-size: 18px;
    letter-spacing: 2px;
    cursor: pointer;
  }
  .panel{
    background: #fff;
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.01);
    .panel-header{
      text-align: left;
      padding: 6px 12px;
      margin: 0 10px;
      border-bottom: 1px solid hsla(0,0%,85%,.5);
      .title{
        font-size:16px;
        margin: 10px 0;
      }
    }
  }
  .table-common-main-lang{
    width:100%;
  }
  .table-common-main-lang th{
    padding: 15px 10px;
    border-bottom:1px solid #e8e8e8;
  }
  .table-common-main-lang td{
    padding: 10px 8px;
    border-bottom:1px solid #e8e8e8;
  }
  .query{
    text-align: left;
    margin-bottom: 10px;
  }
  .query .el-row {
    text-align: left;
    margin-bottom: 10px;
  }
  .query .label{
    margin-left: 20px;
  }
  .query .el-button--primary{
    margin-left: 20px;
  }
  .query .el-pagination{
    float: right;
    margin: 20px 0;
  }
  .query .usernameInput{
    width: 240px;
  }
</style>
