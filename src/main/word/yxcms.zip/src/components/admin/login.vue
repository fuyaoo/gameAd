<template>
  <div id="login">
    <table></table>
    <div class="loginBox">
      <table></table>
      <div class="head"><img src="../../assets/images/lion.png" alt=""></div>
      <div class="title">游戏代理管理后台</div>
      <form>
        <input type="text" name="" class="input" placeholder="用户名" v-model="loginForm.username">
        <input type="password" name="" class="input" placeholder="密 码" v-model="loginForm.password">
        <div @click="submit">登录</div>
      </form>
    </div>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'login',
    data () {
      return {
        loginForm: {
          username: '',
          password: ''
        }
      }
    },
    methods: {
      submit () {
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + '/gameAd/login',
          method: 'post',
          params: this.loginForm
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            // console.log('x')
            this.$store.commit('SETTOKEN', obj.data.data)
            sessionStorage.setItem('token', obj.data.data)
            this.$router.push('/seloneRelation')
          }
        })
      }
    }
  }
</script>
<style>
  #login{
    width: 100vw;
    height: 100vh;
    background: url('../../assets/images/loginbg.jpg') center center;
    background-size: cover;
    overflow: hidden;
  }
  .loginBox{
    box-sizing: border-box;
    width: 520px;
    height: 360px;
    margin: 200px auto 0;
    background: #fff;
    border-radius: 4px;
    padding: 0 80px;
  }
  .loginBox > .title{
    font-size: 20px;
    color: #333;
    font-weight: bold;
    padding-top: 12px;
    padding-bottom: 30px;
  }
  .loginBox > .head{
    width: 120px;
    height: 120px;
    margin: -60px auto 0;
  }
  .loginBox > .head > img{
    width: 100%;
  }
  .loginBox > form{
    width: 100%;
    overflow: hidden;
  }
  .loginBox > form > div{
    background: #037CFC;
    color: #fff;
    border-radius: 4px;
    padding: 12px 0;
    cursor: pointer;
  }
</style>
