<template>
  <div id="layout">
    <div class="header">
      <div @click="loginout" class="fr loginout">退出</div>
    </div>
    <!-- <div class="sidebar">
      <div>
        <img src="../assets/images/lion.png" alt="" style="width: 80px;padding-top: 20px">
        <div style="border-top: 1px solid #fff;color: #737E8D;width: 100px;margin: 10px auto;padding-top: 2px">后台管理系统</div>
      </div>
      <ul>
        <li><router-link to="/clientPM">移动客户端运维</router-link></li>
        <li><a href="#">营销数据统计</a></li>
        <li><router-link to="/appversion/submenu">Android版本维护</router-link></li>
        <li><a href="#">用户管理</a></li>
      </ul>
    </div> -->
    <router-view></router-view>
  </div>
</template>
<script>
  export default{
    name: 'index',
    methods: {
      loginout () {
        sessionStorage.setItem('token', '')
        this.$router.push('/')
      }
    }
  }
</script>
<style>
  #layout .header{
    width: 100%;
    height: 70px;
    background: #fff;
    box-shadow: 0 1px 2px 0 rgba(153,153,153,0.30);
  }
  #layout .sidebar{
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 140px;
    background: #313641;
  }
  #layout .loginout{
    float: right;
    margin-right: 20px;
    line-height: 70px;
    cursor: pointer;
  }
</style>
