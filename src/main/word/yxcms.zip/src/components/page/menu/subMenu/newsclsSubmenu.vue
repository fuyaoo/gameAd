<template>
  <div id="newsSubmenu">
    <ul class="menuRow" v-show="this.menuNum">
      <li :class="{'active': this.$store.state.stateRow[0] === 1}"><router-link to="/newsInstallPage">栏目设置</router-link></li>
      <li v-for="(item, index) in menuNum" >
        <router-link to="/newsInstallPage">{{item.clsName}}</router-link>
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'newsSubmenu',
    data () {
      return {
        menuNum: []
      }
    },
    beforeCreate () {
      this.$store.commit('CHANGESTATE', [1, 0, 0, 0, 0, 0])
    },
    created () {
      var that = this
      axios({
        url: this.$store.state.baseURI + 'oss/info/class/list',
        method: 'get',
        params: {page_num: 1, token: that.$store.state.token}
      }).then(obj => {
        if (obj.data.code === 100) {
          this.menuNum = obj.data.data.list
          console.log(this.menuNum)
        }
      })
    }
  }
</script>
<style></style>
