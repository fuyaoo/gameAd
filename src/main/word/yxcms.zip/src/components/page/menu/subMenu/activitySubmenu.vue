<template>
  <div id="activitySubmenu">
    <ul class="menuRow">
      <li :class="{'active': this.$store.state.stateRow[0] === 1}"><router-link to="/bannerPage">轮播图</router-link></li>
      <li :class="{'active': this.$store.state.stateRow[1] === 1}"><router-link to="/activityPage">活动专区</router-link></li>
      <li :class="{'active': this.$store.state.stateRow[2] === 1}"><router-link to="/adPage">弹窗广告</router-link></li>
      <li :class="{'active': this.$store.state.stateRow[3] === 1}"><router-link to="/flashAdPage">快讯广告</router-link></li>
    </ul>
    <router-view></router-view>
  </div>
</template>
<script>
  export default{
    name: 'activitySubmenu'
  }
</script>
<style>
</style>
