<template>
  <div id="newsSubmenu">
    <ul class="menuRow">
      <li :class="{'active': this.$store.state.stateRow[0] === 1}"><router-link to="appversionList">版本列表</router-link></li>
      <li :class="{'active': this.$store.state.stateRow[1] === 1}"><router-link to="appversionNew">新建版本</router-link></li>
    </ul>
    <router-view></router-view>
  </div>
</template>
<script>
  export default{
    name: 'appersionSubmenu'
  }
</script>
<style></style>
