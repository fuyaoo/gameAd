<template>
  <div id="newsSubmenu">
    <ul class="menuRow" v-show="this.menuNum">
      <li><router-link to="/newsInstallPage">栏目设置</router-link></li>
      <li v-for="(item, index) in menuNum" @click="setChangestate(index, item.clsId)">
        <router-link  :to="{ path: '/newsclsPage/' + item.clsId, params: { clsId: item.clsId }}" >{{item.clsName}}</router-link>
      </li>
    </ul>
    <router-view :curClsid="curClsid"></router-view>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'newsSubmenu',
    data () {
      return {
        menuNum: [],
        curClsid: ''
      }
    },
    beforeCreate () {
      this.$store.commit('CHANGESTATE', [1, 0, 0, 0, 0, 0])
    },
    created () {
      var that = this
      axios({
        url: this.$store.state.baseURI + 'oss/info/class/list',
        method: 'get',
        params: {page_num: 1, token: that.$store.state.token}
      }).then(obj => {
        if (obj.data.code === 100) {
          this.menuNum = obj.data.data.list
          console.log(this.menuNum)
        }
      })
    },
    methods: {
      setChangestate (index, clsId) {
        var arr = []
        for (var i = 0; i < this.menuNum.length; i++) {
          if (i === index) {
            arr[index] = 1
          } else {
            arr[i] = 0
          }
        }
        arr.unshift(0)
        this.$store.commit('CHANGESTATE', arr)
        this.curClsid = String(clsId)
      }
    }
  }
</script>
<style>
#newsSubmenu .router-link-active{
  background: #EA5B5A;
    color: #fff;
}
</style>
