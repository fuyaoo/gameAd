<template>
  <div id="profit">
    <el-row class="query">
      <el-col :span="24">
        <span>用户名查询：</span>
        <el-input v-model="usernameInput" placeholder="请输入内容" class="usernameInput"></el-input>
        <span class="label">开始时间：</span>
        <el-date-picker
          v-model="startTime"
          type="date"
          placeholder="选择日期"
          @change="pickerStarttime">
        </el-date-picker>
        <span class="label">结束时间：</span>
        <el-date-picker
          v-model="endTime"
          type="date"
          placeholder="选择日期"
          :picker-options="pickerEndtime">
        </el-date-picker>
        <el-button type="primary" @click="conditionQuery">查询</el-button>
      </el-col>
    </el-row>
    <table class="table">
      <thead>
        <tr>
          <th>代理ID</th>
          <th>分润金额</th>
          <th>昵称</th>
          <th>上级代理</th>
          <th>用户名</th>
          <th>用户ID</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in tableData" :id="item.changeTax" :data-sort="index">
          <td>{{item.agencyid}}</td>
          <td>{{item.changeTax}}</td>
          <td>{{item.nickname}}</td>
          <td>{{item.parentagencyid}}</td>
          <td>{{item.userid}}</td>
          <td>{{item.username}}</td>
        </tr>
      </tbody>
    </table>
    <div class="block" v-if="this.showpagination()">
      <el-pagination
        layout="prev, pager, next"
        :page-size="20"
        @current-change="handleCurrentChange"
        :total="this.count">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'profit',
    data () {
      return {
        count: '',
        tableData: [],
        action: '',
        usernameInput: '',
        startTime: '',
        endTime: ''
      }
    },
    beforeCreate () {
     /* this.$store.commit('CHANGESTATE', [1, 0, 0, 0])
      this.$store.commit('CHANGESTATECOL', [1, 0]) */
    },
    created () {
      this.axios(1)
    },
    methods: {
      // 加载页面
      axios (index) {
        // 代理列表
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/agentCount',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: index
          }
        }).then(obj => {
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.count = obj.data.data.count
          } else {
            sessionStorage.setItem('token', '')
            this.$router.push('/')
          }
        })
      },
      getManageData () {
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/withdrawalsManage',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: 1,
            username: this.usernameInput,
            startTime: this.startTime,
            endTime: this.endTime
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.count = obj.data.data.cunt
          } else {
            // this.$router.push('/')
          }
        })
      },
      conditionQuery () {
        this.getManageData()
      },
      pickerStarttime (e) {
        this.startTime = e
      },
      pickerEndtime (e) {
        this.endTime = e
      },
      showpagination () {
        if (this.count > 20) {
          return true
        } else {
          return false
        }
      },
      handleCurrentChange (e) {
        console.log(e)
        this.axios(e)
      }
    }
  }
</script>
<style>
  .modal{
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background: rgba(0, 0, 0, .4);
  }
  .modal > div{
    box-sizing: border-box;
    width: 570px;
    background: #FFFFFF;
    border-radius: 4px;
    margin: 200px auto 0;
  }
  .modal > div > .modal_header{
    padding: 12px 20px 11px;
    border-bottom: 1px solid #e8e8e8;
    font-size: 16px;
    color: #333;
    text-align: left;
  }
  .modal > div > .modal_header > div{
    float: right;
    cursor: pointer;
  }
  .form{
    padding: 20px 80px;
  }
  .form-group{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 20px;
  }
  .form-group > label:first-child{
    width: 80px;
    font-size: 16px;
  }
  .form-group > input{
    display: block;
    padding: 12px 20px;
    background: #FFFFFF;
    border: 1px solid #E8E8E8;
    box-shadow: 0 0px 1px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    width: calc(100% - 150px);
    font-size: 14px;
  }
  .form-group > input::-webkit-input-placeholder{
    color: #A5AFBA;
  }
  .btn{
    width: 132px;
    height: 40px;
    background: #037CFC;
    box-shadow: 0 1px 2px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    border: none;
    color: #fff;
    font-size: 18px;
    letter-spacing: 2px;
    cursor: pointer;
  }
  #profit .el-pagination{
    text-align: right;
    margin: 10px 0;
  }
</style>
