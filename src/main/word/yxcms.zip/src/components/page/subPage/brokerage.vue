<template>
  <div id="brokerage">
    <el-row>
      <el-col :span="24">
        <div class="panel pd20">
          <p>当前一级佣金率为：<span class="currentbrokerage">{{oneRate}}%</span>当前二级佣金率为：<span class="currentbrokerage">{{twoRate}}%</span>当前三级佣金率为：<span class="currentbrokerage">{{threeRate}}%</span></p>
          <h3 class="tl title">设置佣金率</h3>
          <span>一级佣金率：</span><el-input v-model="oneRate" placeholder="请输入内容"></el-input>
          <span>二级佣金率：</span><el-input v-model="twoRate" placeholder="请输入内容"></el-input>
          <span>三级佣金率：</span><el-input v-model="threeRate" placeholder="请输入内容"></el-input>
          <el-button type="primary" @click="setBrokerage">设置</el-button>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'bannerPage',
    data () {
      return {
        currentbrokerage: 0,
        oneRate: 0,
        twoRate: 0,
        threeRate: 0
      }
    },
    beforeCreate () {
    },
    created () {
      this.axios(1)
    },
    methods: {
      // 加载页面
      axios (index) {
        // 代理列表
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/rate',
          method: 'GET',
          params: {
            token: sessionStorage.token
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            // this.currentbrokerage = obj.data.data
            console.log(obj.data.onerate)
            this.oneRate = obj.data.data.onerate
            this.twoRate = obj.data.data.tworate
            this.threeRate = obj.data.data.threerate
          } else {
            sessionStorage.setItem('token', '')
            this.$router.push('/')
          }
        })
      },
      setBrokerage () {
        // 代理列表
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/rate/insert  ',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            oneRate: this.oneRate,
            twoRate: this.twoRate,
            threeRate: this.threeRate
          }
        }).then(obj => {
          console.log(obj)
          /* if (obj.data.code === 100) {
            this.currentbrokerage = obj.data.data.list
          } */
        })
      }
    }
  }
</script>
<style>
  #brokerage .panel{
    text-align: left;
  }
  #brokerage .panel .title{
    padding: 10px 0;
  }
  #brokerage  .el-input {
    width: 240px;
    margin-right: 20px;
  }
  .currentbrokerage{
    color: red;
    font-weight: bold;
    margin-right: 10px;
  }
</style>
