<template>
  <div id="seloneRelation">
    <div class="">
      <el-row class="query">
        <el-col :span="24">
          <span>用户名查询：</span>
          <el-input v-model="usernameInput" placeholder="请输入内容" class="usernameInput"></el-input>
          <el-button type="primary" @click="conditionQuery">查询</el-button>
        </el-col>
      </el-row>
      <div class="outtable">
        <table class="fixedtable table">
          <thead>
            <tr>
              <th width="15%">ID</th>
                <th width="15%">代理ID</th>
                <th width="15%">昵称</th>
                <th width="15%">上级代理</th>
                <th width="20%">用户名</th>
                <th width="20%">用户ID</th>
            </tr>
          </thead>
        </table>
        <div class="tablescroll">
          <table class="table">
            <thead>
              <tr>
                <th width="15%">ID</th>
                <th width="15%">代理ID</th>
                <th width="15%">昵称</th>
                <th width="15%">上级代理</th>
                <th width="20%">用户名</th>
                <th width="20%">用户ID</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in tableData" :id="item.changeTax" :data-sort="index" @click="getnextInfo(item.nickname, item.agencyid)">
                <td>{{item.agencyid}}</td>
                <td>{{item.changeTax}}</td>
                <td>{{item.nickname}}</td>
                <td>{{item.parentagencyid}}</td>
                <td>{{item.userid}}</td>
                <td>{{item.username}}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="block tr" v-if="showpagination(this.tableCount)">
          <el-pagination
            layout="prev, pager, next"
            :total="this.tableCount"
            :page-size="20"
            class="tr"
            @current-change="handleCurrentChange"
            >
          </el-pagination>
        </div>
      </div>
    </div>
    <el-row class="One" v-if="this.tableOneData.length">
      <el-col :span="24">
        <div class="panel">
          <div class="header">
            <span><span class="strong">{{currentOneData.name}}</span>的一級代理：</span>
          </div>
        </div>
        <div class="tablescroll">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>代理ID</th>
                <th>昵称</th>
                <th>上级代理</th>
                <th>用户名</th>
                <th>用户ID</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in tableOneData" :id="item.changeTax" :data-sort="index" @click="getSecondData(item.nickname, item.agencyid)">
                <td>{{item.agencyid}}</td>
                <td>{{item.changeTax}}</td>
                <td>{{item.nickname}}</td>
                <td>{{item.parentagencyid}}</td>
                <td>{{item.userid}}</td>
                <td>{{item.username}}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="block tr" v-if="showpagination(this.tableOneDataCount)">
          <el-pagination
            layout="prev, pager, next"
            :total="this.tableOneDataCount"
            :page-size="20"
            class="tr"
            @current-change="handleOneDataChange"
            >
          </el-pagination>
        </div>
      </el-col>
    </el-row>
    <el-row class="second" v-if="this.tableSecondData.length">
      <el-col :span="24">
        <div class="panel">
          <div class="header">
            <span><span class="strong">{{currentOneData.name}}</span>的二级代理：</span>
            <span><span class="strong">{{currentSecondData.name}}</span>的一级代理：</span>
          </div>
        </div>
        <div class="tablescroll">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>代理ID</th>
                <th>昵称</th>
                <th>上级代理</th>
                <th>用户名</th>
                <th>用户ID</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in tableSecondData" :id="item.changeTax" :data-sort="index" @click="getThirdData(item.nickname, item.agencyid)">
                <td>{{item.agencyid}}</td>
                <td>{{item.changeTax}}</td>
                <td>{{item.nickname}}</td>
                <td>{{item.parentagencyid}}</td>
                <td>{{item.userid}}</td>
                <td>{{item.username}}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="block tr" v-if="showpagination(this.tableOneDataCount)">
          <el-pagination
            layout="prev, pager, next"
            :total="this.tableSecondDataCount"
            :page-size="20"
            class="tr"
            @current-change="handleSecondDataChange"
            >
          </el-pagination>
        </div>
      </el-col>
    </el-row>
    <el-row class="third" v-if="this.tableThirdData.length">
      <el-col :span="24">
        <div class="panel">
          <div class="header">
            <span><span class="strong">{{currentOneData.name}}</span>的三级代理：</span>
            <span><span class="strong">{{currentSecondData.name}}</span>的二级代理：</span>
            <span><span class="strong">{{currentThirdData.name}}</span>的一级代理：</span>
          </div>
        </div>
        <div class="tablescroll">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>代理ID</th>
                <th>昵称</th>
                <th>上级代理</th>
                <th>用户名</th>
                <th>用户ID</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in tableThirdData" :id="item.changeTax" :data-sort="index">
                <td>{{item.agencyid}}</td>
                <td>{{item.changeTax}}</td>
                <td>{{item.nickname}}</td>
                <td>{{item.parentagencyid}}</td>
                <td>{{item.userid}}</td>
                <td>{{item.username}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'bannerPage',
    data () {
      return {
        tableCount: 0,
        tableData: [],
        currentOneData: {
          name: '',
          id: ''
        },
        tableOneDataCount: 0,
        tableOneData: [],
        currentSecondData: {
          name: '',
          id: ''
        },
        tableSecondDataCount: 0,
        tableSecondData: [],
        currentThirdData: {
          name: '',
          id: ''
        },
        tableThirdDataCount: 0,
        tableThirdData: [],
        action: '',
        usernameInput: '',
        startTime: '',
        endTime: ''
      }
    },
    beforeCreate () {
      this.$store.commit('CHANGESTATE', [1, 0, 0, 0])
      this.$store.commit('CHANGESTATECOL', [1, 0])
    },
    created () {
      this.axios(1)
    },
    methods: {
      // 加载页面
      axios (index) {
        // 代理列表
        console.log(sessionStorage.token)
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/seloneRelation',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: index
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.tableCount = obj.data.data.count
          } else {
            sessionStorage.setItem('token', '')
            this.$router.push('/')
          }
        })
      },
      pagination (index) {
        console.log(index)
        this.axios(index)
      },
      getnextInfo (name, id) {
        this.currentOneData.name = name
        this.currentOneData.id = id
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/selNextRelation',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            agencyID: id
          }
        }).then(obj => {
          if (obj.data.code === 100) {
            if (obj.data.data.length > 0) {
              this.tableOneData = obj.data.data
              this.tableOneDataCount = obj.data.data.length
              this.tableSecondData = ''
              this.tableThirdData = ''
              console.log(this.tableSecondData)
            }
          }
        })
      },
      getManageData () {
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/withdrawalsManage',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: 1,
            username: this.usernameInput,
            startTime: this.startTime,
            endTime: this.endTime
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.count = obj.data.data.cunt
            this.tableSecondData = ''
            this.tableThirdData = ''
          } else {
            // this.$router.push('/')
          }
        })
      },
      getSecondData (name, id) {
        this.currentSecondData.name = name
        this.currentSecondData.id = id
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/selNextRelation',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            agencyID: id
          }
        }).then(obj => {
          if (obj.data.code === 100) {
            if (obj.data.data.length > 0) {
              this.tableSecondData = obj.data.data
              this.tableThirdData = ''
              console.log(this.tableSecondData)
            }
          } else {
            // this.$router.push('/')
          }
        })
      },
      getThirdData (name, id) {
        this.currentThirdData.name = name
        this.currentThirdData.id = id
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/selNextRelation',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            agencyID: id
          }
        }).then(obj => {
          if (obj.data.code === 100) {
            if (obj.data.data.length > 0) {
              this.tableThirdData = obj.data.data
              console.log('third')
            }
          } else {
            // this.$router.push('/')
          }
        })
      },
      conditionQuery () {
        this.getManageData()
      },
      pickerStarttime (e) {
        this.startTime = e
      },
      pickerEndtime (e) {
        this.endTime = e
      },
      showpagination (num) {
        console.log(num)
        if (num > 20) {
          return true
        } else {
          return false
        }
      },
      handleCurrentChange (e) {
        this.axios(e)
      },
      handleOneDataChange (e) {
        this.getnextInfo(this.currentOneData.name, this.currentOneData.id)
      },
      handleSecondDataChange (e) {
        this.getSecondData(this.tableSecondDataCount.name, this.tableSecondDataCount.id)
      },
      handleThirdDataChange (e) {
        this.getThirdData(this.currentThirdData.name, this.currentThirdData.id)
      }
    }
  }
</script>
<style>
  #seloneRelation .query{
  }
  .second, .third,.One{
    margin-top: 20px;
  }
  #seloneRelation .header{
    text-indent: 10px;
    padding: 15px 0;
    height: 20px;
    text-align: left;
    background: #F3F4F9;
    font-weight: bold;
  }
  .strong{
    color: #20a0ff;
    margin-right: 6px;
  }
  #seloneRelation .tablescroll{
    max-height: 370px;
    overflow-y: auto;
    
  }
  #seloneRelation .outtable{
    position: relative;
  }
  #seloneRelation .fixedtable{
    position: absolute;
    left: 0;
    right: 0;
    top:0;
    background: #fff;
    widows: 100%;
  }
  #seloneRelation .fixedtable td{
    padding: 0;
    height: 1px;
  }
  #seloneRelation .el-pagination{
      margin: 10px 0;
  }
</style>
