<template>
  <div id="Manage">
    <el-row class="query">
      <el-col :span="24">
        <span>用户名查询：</span>
        <el-input v-model="usernameInput" placeholder="请输入内容" class="usernameInput"></el-input>
        <span class="label">开始时间：</span>
        <el-date-picker
          v-model="startTime"
          type="date"
          placeholder="选择日期"
          @change="pickerStarttime">
        </el-date-picker>
        <span class="label">结束时间：</span>
        <el-date-picker
          v-model="endTime"
          type="date"
          placeholder="选择日期"
          :picker-options="pickerEndtime">
        </el-date-picker>
        <el-button type="primary" @click="conditionQuery">查询</el-button>
      </el-col>
    </el-row>
    <table class="table">
      <thead>
        <tr>
        <th>ID</th>
          <th>代理ID</th>
          <th>用户名</th>
          <th>审核时间</th>
          <th>创建时间</th>
          
          <th>金额</th>
          <th>状态</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in tableData" :id="item.changeTax" :data-sort="index">
        <td>{{item.id}}</td>
          <td>{{item.agencyid}}</td>
          <td>{{item.username}}</td>
          <td>{{item.auditingtime}}</td>
          <td>{{item.createtime}}</td>
          
          <td>{{item.money}}</td>
          <td>
            <span v-if="item.status===0">待审核</span>
            <span v-if="item.status===1">通过</span>
            <span v-if="item.status===2">不通过</span>
          </td>
          <td>
            <div v-if="item.status===0">
              <span  @click="withdrawalsUpdate(item.id, 1)" class="submitsh pass">通过</span>
              <span  @click="withdrawalsUpdate(item.id, 2)" class="submitsh nopass">不审核</span>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="block" v-if="this.showpagination()">
      <el-pagination
        layout="prev, pager, next"
        @current-change="handleCurrentChange"
        :total="this.count">
      </el-pagination>
    </div>
  </div>
</template>
<script>
  import axios from 'axios'
  export default{
    name: 'manage',
    data () {
      return {
        count: 0,
        tableData: [],
        usernameInput: '',
        startTime: '',
        endTime: ''
      }
    },
    beforeCreate () {
     /* this.$store.commit('CHANGESTATE', [1, 0, 0, 0])
      this.$store.commit('CHANGESTATECOL', [1, 0]) */
    },
    created () {
      this.axios(1)
    },
    methods: {
      // 加载页面
      axios (index) {
        // 代理列表
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/withdrawalsManage',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: index
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.count = obj.data.data.cunt
          } else {
            sessionStorage.setItem('token', '')
            this.$router.push('/')
          }
        })
      },
      getManageData () {
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/withdrawalsManage',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            page_num: 1,
            username: this.usernameInput,
            startTime: this.startTime,
            endTime: this.endTime
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.tableData = obj.data.data.list
            this.count = obj.data.data.cunt
          } else {
            // this.$router.push('/')
          }
        })
      },
      conditionQuery () {
        this.getManageData()
      },
      pickerStarttime (e) {
        this.startTime = e
      },
      pickerEndtime (e) {
        this.endTime = e
      },
      showpagination () {
        if (this.count > 20) {
          return true
        } else {
          return false
        }
      },
      withdrawalsUpdate (id, status) {
        // 审核
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          url: process.env.API_ROOT + 'gameAd/tAgency/withdrawalsUpdate',
          method: 'POST',
          params: {
            token: sessionStorage.token,
            id: id,
            status: status
          }
        }).then(obj => {
          console.log(obj)
          if (obj.data.code === 100) {
            this.axios(1)
          } else {
            // this.$router.push('/')
          }
        })
      },
      handleCurrentChange (e) {
        this.axios(e)
      }
    }
  }
</script>
<style>
  .submitsh{
    cursor: pointer;
  }
  .form{
    padding: 20px 80px;
  }
  .form-group{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 20px;
  }
  .form-group > label:first-child{
    width: 80px;
    font-size: 16px;
  }
  .form-group > input{
    display: block;
    padding: 12px 20px;
    background: #FFFFFF;
    border: 1px solid #E8E8E8;
    box-shadow: 0 0px 1px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    width: calc(100% - 150px);
    font-size: 14px;
  }
  .form-group > input::-webkit-input-placeholder{
    color: #A5AFBA;
  }
  .btn{
    width: 132px;
    height: 40px;
    background: #037CFC;
    box-shadow: 0 1px 2px 0 rgba(153,153,153,0.30);
    border-radius: 4px;
    border: none;
    color: #fff;
    font-size: 18px;
    letter-spacing: 2px;
    cursor: pointer;
  }
  .pass{
    color: #1AAD16
  }
  .nopass{
    color: #c82829
  }
</style>
