/*
* @Author: Marte
* @Date:   2017-07-26 09:12:15
* @Last Modified by:   Marte
* @Last Modified time: 2017-07-26 09:28:58
*/
import axios from 'axios'
export default{
  install (Vue, option) {
    Vue.prototype.getFormToken = function () {
      axios({
        url: this.$store.state.baseURI + 'oss/info/get/form/token',
        method: 'get',
        params: {token: this.$store.state.token}
      }).then(obj => {
        if (obj.data.code === 100) {
          this.form_token = obj.data.data
        } else {
          this.$router.push('/')
        }
      })
    }

    Vue.prototype.formatTime = function (value) {
      var date = new Date(value)
      var seperator1 = '-'
      var seperator2 = ':'
      var month = date.getMonth() + 1
      var strDate = date.getDate()
      var hours = date.getHours()
      var minutes = date.getMinutes()
      var seconds = date.getSeconds()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      if (hours >= 0 && hours <= 9) {
        hours = '0' + hours
      }
      if (minutes >= 0 && minutes <= 9) {
        minutes = '0' + minutes
      }
      if (seconds >= 0 && seconds <= 9) {
        seconds = '0' + seconds
      }
      var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate + ' ' + hours + seperator2 + minutes + seperator2 + seconds
      return currentdate
    }
  }
}
