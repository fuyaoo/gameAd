import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'login',
      component: resolve => require(['@/components/admin/login'], resolve)
    },
    {
      path: '/index',
      name: 'index',
      component: resolve => require(['@/components/index'], resolve),
      children: [
        {
          path: '/clientPM',
          name: 'clientPM',
          component: resolve => require(['@/components/page/menu/clientPM'], resolve),
          children: [
            {
              path: '/seloneRelation',
              name: 'seloneRelation',
              component: resolve => require(['@/components/page/subPage/seloneRelation'], resolve)
            },
            {
              path: '/profit',
              name: 'profit',
              component: resolve => require(['@/components/page/subPage/profit'], resolve)
            },
            {
              path: '/manage',
              name: 'manage',
              component: resolve => require(['@/components/page/subPage/manage'], resolve)
            },
            {
              path: '/brokerage',
              name: 'brokerage',
              component: resolve => require(['@/components/page/subPage/brokerage'], resolve)
            }
          ]
        }
      ]
    }
  ]
})
