/*
* @Author: Marte
* @Date:   2017-07-13 16:56:38
* @Last Modified by:   Marte
* @Last Modified time: 2017-07-27 15:21:36
*/
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
export default new Vuex.Store({
  state: {
    baseURI: 'http://119.23.35.234/',
    token: sessionStorage.getItem('token'),
    stateRow: [0, 0, 0, 0, 0, 0, 0, 0],
    stateCol: [0, 0],
    adPageForm: {
      file: '',
      activityPageTitle: '',
      activityPageUrl: '',
      activityPageStartTime: '',
      activityPageEndTime: '',
      activityScopePage: 0,
      scopeDescriptionPage: '',
      activityPageId: ''
    },
    clsId: ''
  },
  mutations: {
    SETTOKEN (state, token) {
      state.token = token
    },
    CHANGESTATE (state, stateRow) {
      state.stateRow = stateRow
    },
    CHANGESTATECOL (state, stateCol) {
      state.stateCol = stateCol
    },
    CHANGECLSID (state, clsId) {
      state.clsId = clsId
    }
  },
  actions: {
    setToken ({commit}) {
      commit('SETTOKEN')
    }
  }
})

